import {v4 as uuidv4} from "uuid";
//TODAY: GET 12 songs
const chillHop = () => {
    return [
        {
           name: "Jazz Cabbage",
           artist: "Ian Ewing, Strehlow",
           cover: "https://i.scdn.co/image/ab67616d0000b273ccdcf06294e4503bd0530297",
           id: uuidv4(),
           active: true,
           color: ["#D54948", "#FD9F5F"],
           audio: "https://mp3.chillhop.com/serve.php/?mp3=12134"
        },

        {
            name: "Higher",
            artist: "Misha, Jussi Halme",
            cover: "https://i.scdn.co/image/ab67616d0000b27382a863c04b0f7d55c8afed01",
            id: uuidv4(),
            active: false,
            color: ["#AC9FB3", "#FE5572"],
            audio: "https://mp3.chillhop.com/serve.php/?mp3=15088"
        },
        /*REPLACE ALL DATA BELOW AFTER IMPLEMENTATION/BEFORE PRODUCTION*/
        
    ];
}

export default chillHop;